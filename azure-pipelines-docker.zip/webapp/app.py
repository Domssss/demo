from flask import Flask, request, jsonify
import redis
import os
import json

app = Flask(__name__)

redis_host = '10.0.0.5'
redis_port = 6380
redis_password = 'biExf4kqhunXrmQkPzz9n7Cgj5cY9Bbv2AzCaO1M4zY='

r = redis.Redis(host=redis_host, port=redis_port, password=redis_password, ssl=True)

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({"status": "ok"})

@app.route('/api/mirror', methods=['GET'])
def mirror_word():
    word = request.args.get('word', '')
    transformed_word = ''.join([char.upper() if char.islower() else char.lower() if char.isupper() else char for char in word])[::-1]
    r.set(word, transformed_word)
    return jsonify({"transformed": transformed_word})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=4004)
